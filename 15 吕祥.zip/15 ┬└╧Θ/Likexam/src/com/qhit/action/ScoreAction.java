package com.qhit.action;

import java.util.ArrayList;

import com.qhit.bean.Direction;
import com.qhit.bean.Paper;
import com.qhit.bean.Score;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.biz.ScoreBiz;
import com.qhit.biz.impl.ScoreBizImpl;
import com.qhit.util.PageBean;

public class ScoreAction {
	private ArrayList<Direction> dirList;
	private ArrayList<Stage> staList;
	private ArrayList<Subject> subList;
	private int dirOpValue;
	private int staOpValue;
	private int subOpValue;
	private ScoreBiz sb = new ScoreBizImpl();
	private PageBean paperPb;
	private int p;
	private int pid;
	private ArrayList<Score> scoreList = new ArrayList<Score>();
	private ArrayList<Paper> paperList;
	private int Count;
	private int passCount;
	private int passRate;
	private String snameStr;
	public String ScoreIndex(){
		dirList = sb.getDirList();
		staList = sb.getStageList();
		subList = sb.getSubjectListByDidAndStaid(1, 1);
		Subject sub = subList.get(0);
		int psubid = sub.getSubid();
		int up = 1;
		if (p!=0)up=p;
		paperPb = sb.getPaperByPageBean(up, psubid);
		return "ScoreIndex";
	}
	
	public String DirStaonChange(){
		dirList = sb.getDirList();
		staList = sb.getStageList();
		subList = sb.getSubjectListByDidAndStaid(dirOpValue, staOpValue);
		Subject sub = subList.get(0);
		int psubid = sub.getSubid();
		int up = 1;
		if (p!=0)up=p;
		paperPb = sb.getPaperByPageBean(up, psubid);
		return "ScoreIndex";
	}
	
	public String subOnChange(){
		dirList = sb.getDirList();
		staList = sb.getStageList();
		subList = sb.getSubjectListByDidAndStaid(dirOpValue, staOpValue);
		int up = 1;
		if (p!=0)up=p;
		paperPb = sb.getPaperByPageBean(up, subOpValue);
		return "ScoreIndex";
	}
	
	//�鿴�ɼ�
	public String lookScore(){
		paperList = sb.getPaper(pid);
		scoreList = sb.getScoreByPid(pid);
		Count = sb.getCountBypid(pid);
		passCount = sb.getPassCount(pid);
		
		try {
			;
			;
			passRate = (int) ((Double.parseDouble(passCount+"")/Double.parseDouble(Count+""))*100);
		} catch (Exception e) {
			passRate = 0;
		}
		
		return "lookScore";
	}
	
	//�������ؼ��ֲ�ѯѧ���ɼ�
	public String StudentInfo(){
		paperList = sb.getPaper(pid);
		Count = sb.getCountBypid(pid);
		passCount = sb.getPassCount(pid);
		try {
			passRate = (passCount/Count)*100;
		} catch (Exception e) {
			passRate = 0;
		}
		if (snameStr.equals(" ")) {
			scoreList = sb.getScoreByPid(pid);
		}else{
			ArrayList<Student> stuList = sb.getStudentsByNameStr(snameStr);
			for (Student s : stuList) {
				int sid = s.getSid();
				ArrayList<Score> sc = new ArrayList<Score>();
				sc = sb.getScoreByPidAndSid(pid, sid);
				Score score = sc.get(0);
				scoreList.add(score);
			}
		}
		return "lookScore";
	}

	public ArrayList<Direction> getDirList() {
		return dirList;
	}

	public void setDirList(ArrayList<Direction> dirList) {
		this.dirList = dirList;
	}

	public ArrayList<Stage> getStaList() {
		return staList;
	}

	public void setStaList(ArrayList<Stage> staList) {
		this.staList = staList;
	}

	public ArrayList<Subject> getSubList() {
		return subList;
	}

	public void setSubList(ArrayList<Subject> subList) {
		this.subList = subList;
	}

	public ScoreBiz getSb() {
		return sb;
	}

	public void setSb(ScoreBiz sb) {
		this.sb = sb;
	}

	public PageBean getPaperPb() {
		return paperPb;
	}

	public void setPaperPb(PageBean paperPb) {
		this.paperPb = paperPb;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getDirOpValue() {
		return dirOpValue;
	}

	public void setDirOpValue(int dirOpValue) {
		this.dirOpValue = dirOpValue;
	}

	public int getStaOpValue() {
		return staOpValue;
	}

	public void setStaOpValue(int staOpValue) {
		this.staOpValue = staOpValue;
	}

	public int getSubOpValue() {
		return subOpValue;
	}

	public void setSubOpValue(int subOpValue) {
		this.subOpValue = subOpValue;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public ArrayList<Score> getScoreList() {
		return scoreList;
	}

	public void setScoreList(ArrayList<Score> scoreList) {
		this.scoreList = scoreList;
	}

	public ArrayList<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(ArrayList<Paper> paperList) {
		this.paperList = paperList;
	}

	public int getCount() {
		return Count;
	}

	public void setCount(int count) {
		Count = count;
	}

	public int getPassCount() {
		return passCount;
	}

	public void setPassCount(int passCount) {
		this.passCount = passCount;
	}

	public int getPassRate() {
		return passRate;
	}

	public void setPassRate(int passRate) {
		this.passRate = passRate;
	}

	public String getSnameStr() {
		return snameStr;
	}

	public void setSnameStr(String snameStr) {
		this.snameStr = snameStr;
	}
	
	
}

package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * ExamQuestion entity. @author MyEclipse Persistence Tools
 */

public class ExamQuestion implements java.io.Serializable {

	// Fields

	private Integer eid;
	private Subject subject;
	private String efirstType;
	private String echooseType;
	private String econtent;
	private String eoptionA;
	private String eoptionB;
	private String eoptionC;
	private String eoptionD;
	private String eanswer;
	private String edifficultLevel;
	private String echapter;
	private Set paperEqs = new HashSet(0);
	private Set stuPaperEqs = new HashSet(0);

	// Constructors

	/** default constructor */
	public ExamQuestion() {
	}

	/** minimal constructor */
	public ExamQuestion(Integer eid) {
		this.eid = eid;
	}

	/** full constructor */
	public ExamQuestion(Integer eid, Subject subject, String efirstType,
			String echooseType, String econtent, String eoptionA,
			String eoptionB, String eoptionC, String eoptionD, String eanswer,
			String edifficultLevel, String echapter, Set paperEqs,
			Set stuPaperEqs) {
		this.eid = eid;
		this.subject = subject;
		this.efirstType = efirstType;
		this.echooseType = echooseType;
		this.econtent = econtent;
		this.eoptionA = eoptionA;
		this.eoptionB = eoptionB;
		this.eoptionC = eoptionC;
		this.eoptionD = eoptionD;
		this.eanswer = eanswer;
		this.edifficultLevel = edifficultLevel;
		this.echapter = echapter;
		this.paperEqs = paperEqs;
		this.stuPaperEqs = stuPaperEqs;
	}

	// Property accessors

	public Integer getEid() {
		return this.eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getEfirstType() {
		return this.efirstType;
	}

	public void setEfirstType(String efirstType) {
		this.efirstType = efirstType;
	}

	public String getEchooseType() {
		return this.echooseType;
	}

	public void setEchooseType(String echooseType) {
		this.echooseType = echooseType;
	}

	public String getEcontent() {
		return this.econtent;
	}

	public void setEcontent(String econtent) {
		this.econtent = econtent;
	}

	public String getEoptionA() {
		return this.eoptionA;
	}

	public void setEoptionA(String eoptionA) {
		this.eoptionA = eoptionA;
	}

	public String getEoptionB() {
		return this.eoptionB;
	}

	public void setEoptionB(String eoptionB) {
		this.eoptionB = eoptionB;
	}

	public String getEoptionC() {
		return this.eoptionC;
	}

	public void setEoptionC(String eoptionC) {
		this.eoptionC = eoptionC;
	}

	public String getEoptionD() {
		return this.eoptionD;
	}

	public void setEoptionD(String eoptionD) {
		this.eoptionD = eoptionD;
	}

	public String getEanswer() {
		return this.eanswer;
	}

	public void setEanswer(String eanswer) {
		this.eanswer = eanswer;
	}

	public String getEdifficultLevel() {
		return this.edifficultLevel;
	}

	public void setEdifficultLevel(String edifficultLevel) {
		this.edifficultLevel = edifficultLevel;
	}

	public String getEchapter() {
		return this.echapter;
	}

	public void setEchapter(String echapter) {
		this.echapter = echapter;
	}

	public Set getPaperEqs() {
		return this.paperEqs;
	}

	public void setPaperEqs(Set paperEqs) {
		this.paperEqs = paperEqs;
	}

	public Set getStuPaperEqs() {
		return this.stuPaperEqs;
	}

	public void setStuPaperEqs(Set stuPaperEqs) {
		this.stuPaperEqs = stuPaperEqs;
	}

}
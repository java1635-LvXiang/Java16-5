package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Classs entity. @author MyEclipse Persistence Tools
 */

public class Classs implements java.io.Serializable {

	// Fields

	private Integer cid;
	private String cname;
	private Set students = new HashSet(0);
	private Set papers = new HashSet(0);

	// Constructors

	/** default constructor */
	public Classs() {
	}

	/** minimal constructor */
	public Classs(Integer cid) {
		this.cid = cid;
	}

	/** full constructor */
	public Classs(Integer cid, String cname, Set students, Set papers) {
		this.cid = cid;
		this.cname = cname;
		this.students = students;
		this.papers = papers;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

	public Set getPapers() {
		return this.papers;
	}

	public void setPapers(Set papers) {
		this.papers = papers;
	}

}
package com.qhit.util;

public class PaperContent {
	private int pcid;//�������
	private String stuanswer;//ѧ����
	
	
	public int getPcid() {
		return pcid;
	}
	public void setPcid(int pcid) {
		this.pcid = pcid;
	}
	public String getStuanswer() {
		return stuanswer;
	}
	public void setStuanswer(String stuanswer) {
		this.stuanswer = stuanswer;
	}
	
	
	
	
}

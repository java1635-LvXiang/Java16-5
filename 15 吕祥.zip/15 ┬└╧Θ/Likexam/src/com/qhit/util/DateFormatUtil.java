package com.qhit.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatUtil {
	public String getDate(Date date){
		String dated = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		dated = sdf.format(date);
		return dated;
	}
}
